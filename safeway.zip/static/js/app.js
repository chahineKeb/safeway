/* ══════════════════════════════════════════════════
   CONSTANTES
══════════════════════════════════════════════════ */
const TOULOUSE = [43.6045, 1.4440];

const TILE_LIGHT = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const TILE_DARK  = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';

const ATTR_LIGHT = '© <a href="https://openstreetmap.org">OpenStreetMap</a>';
const ATTR_DARK  = '© <a href="https://openstreetmap.org">OpenStreetMap</a> © <a href="https://carto.com/attributions">CARTO</a>';

const COLORS = { inquietude:'#fb923c', agression:'#ea580c', urgence:'#dc2626' };
const LABELS = { inquietude:'Inquiétude', agression:'Agression', urgence:'Urgence Police' };

const BADGE_STYLE = {
  inquietude: { bg:'#fff7ed', color:'#9a3412' },
  agression:  { bg:'#fff3e0', color:'#7c2d12' },
  urgence:    { bg:'#fef2f2', color:'#991b1b' }
};

const CONFIRM = {
  inquietude: { title:'⚠️ Signaler une inquiétude', desc:'Vous vous sentez suivie ou surveillée. Une alerte sera envoyée aux Veilleurs dans un rayon de 500 m.', bg:'#fb923c', label:'Envoyer l\'alerte' },
  agression:  { title:'🟠 Signaler une agression',  desc:'Vous êtes victime ou témoin d\'une agression. Les Veilleurs et agents proches seront alertés.', bg:'#ea580c', label:'Envoyer l\'alerte' },
  urgence:    { title:'🚨 Contacter la Police — 17', desc:'Une intervention immédiate est nécessaire. La police sera contactée et votre position transmise.', bg:'#dc2626', label:'Appeler la police' }
};

const TOAST_MSG = {
  inquietude:'✅ Alerte envoyée — les Veilleurs ont été notifiés',
  agression: '✅ Alerte envoyée — intervention en cours',
  urgence:   '🚨 Police contactée — de l\'aide arrive'
};

/* ══════════════════════════════════════════════════
   ÉTAT
══════════════════════════════════════════════════ */
let map, tileLayer, userMarker;
let pendingLevel  = null;
let toastTimer    = null;
let currentFilter = 'all';
let allAlerts     = [];

/* ══════════════════════════════════════════════════
   NAVIGATION
══════════════════════════════════════════════════ */
function switchScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));

  document.getElementById(`screen-${name}`).classList.add('active');
  const btn = document.querySelector(`.nav-item[data-screen="${name}"]`);
  if (btn) btn.classList.add('active');

  // Légende : visible uniquement sur la carte
  const legend = document.getElementById('map-legend');
  if (legend) legend.style.display = name === 'carte' ? 'flex' : 'none';

  // Leaflet perd ses dimensions si le conteneur était masqué
  if (name === 'carte' && map) setTimeout(() => map.invalidateSize(), 60);

  if (name === 'alertes') renderAlertsList();
}

/* ══════════════════════════════════════════════════
   DARK MODE
══════════════════════════════════════════════════ */
function toggleDarkMode() {
  const isDark = document.body.classList.toggle('dark');
  document.getElementById('dark-icon').textContent = isDark ? '☀️' : '🌙';
  localStorage.setItem('safeway-dark', isDark ? '1' : '0');
  setMapTiles(isDark);
}

function restoreDarkMode() {
  const saved = localStorage.getItem('safeway-dark') === '1';
  if (saved) {
    document.body.classList.add('dark');
    document.getElementById('dark-icon').textContent = '☀️';
  }
  return saved;
}

/* ══════════════════════════════════════════════════
   CARTE — TUILES
══════════════════════════════════════════════════ */
function setMapTiles(dark) {
  if (!map || !tileLayer) return;
  tileLayer.setUrl(dark ? TILE_DARK : TILE_LIGHT);
  tileLayer.options.attribution = dark ? ATTR_DARK : ATTR_LIGHT;
  // Met à jour l'arrière-plan de l'écran téléphone si on est en desktop
  const screen = document.querySelector('.phone-screen');
  if (screen) screen.style.background = dark ? '#0c0a09' : '#fafaf9';
}

/* ══════════════════════════════════════════════════
   CARTE — INITIALISATION
══════════════════════════════════════════════════ */
function initMap() {
  const isDark = document.body.classList.contains('dark');

  map = L.map('map', { zoomControl: true }).setView(TOULOUSE, 14);

  tileLayer = L.tileLayer(isDark ? TILE_DARK : TILE_LIGHT, {
    attribution: isDark ? ATTR_DARK : ATTR_LIGHT,
    maxZoom: 19
  }).addTo(map);

  // Marqueur utilisateur (bleu)
  userMarker = L.circleMarker(TOULOUSE, {
    radius: 9, fillColor: '#3b82f6',
    color: 'white', weight: 3, fillOpacity: 1
  }).addTo(map).bindTooltip('📍 Vous êtes ici', { direction:'top', offset:[0,-12] });

  loadAlerts();
}

/* ══════════════════════════════════════════════════
   ALERTES — CARTE
══════════════════════════════════════════════════ */
function loadAlerts() {
  fetch('/api/alerts')
    .then(r => r.json())
    .then(data => {
      allAlerts = data;
      data.forEach(addMarkerToMap);
      updateCounter();
    })
    .catch(() => showToast('⚠️ Impossible de charger les alertes'));
}

function addMarkerToMap(alert) {
  const color  = COLORS[alert.level] || '#fb923c';
  const radius = alert.level === 'urgence' ? 14 : 11;

  const m = L.circleMarker([alert.lat, alert.lon], {
    radius, fillColor: color, color:'white', weight:2.5, fillOpacity:0.9
  }).addTo(map);

  m.bindTooltip(
    `<strong>${LABELS[alert.level]}</strong><br>${alert.lieu}`,
    { direction:'top', offset:[0, -radius - 4] }
  );
  m.on('click', () => openAlertModal(alert));
  return m;
}

function updateCounter() {
  document.getElementById('stat-alerts').textContent = allAlerts.length;
}

/* ══════════════════════════════════════════════════
   ALERTES — LISTE (onglet)
══════════════════════════════════════════════════ */
function renderAlertsList() {
  fetch('/api/alerts')
    .then(r => r.json())
    .then(data => { allAlerts = data; applyFilter(currentFilter); });
}

function filterAlerts(filter, btn) {
  currentFilter = filter;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  applyFilter(filter);
}

function applyFilter(filter) {
  const list = document.getElementById('alerts-list');
  const data = filter === 'all' ? allAlerts : allAlerts.filter(a => a.level === filter);

  if (!data.length) {
    list.innerHTML = `<p style="text-align:center;color:var(--text-subtle);padding:40px 0;font-size:13px;">Aucune alerte pour ce filtre</p>`;
    return;
  }

  list.innerHTML = data.map(a => {
    // On sérialise l'objet pour le passer en onclick
    const encoded = encodeURIComponent(JSON.stringify(a));
    return `
      <div class="alert-item" onclick="openAlertModal(decodeAndParse('${encoded}'))">
        <div class="alert-dot" style="background:${COLORS[a.level]}"></div>
        <div class="alert-item-content">
          <div class="alert-item-header">
            <span class="alert-item-type">${LABELS[a.level]}</span>
            <span class="alert-item-time">⏱ ${a.heure}</span>
          </div>
          <div class="alert-item-lieu">${a.lieu}</div>
          <div class="alert-item-desc">${a.description}</div>
        </div>
      </div>`;
  }).join('');
}

function decodeAndParse(str) { return JSON.parse(decodeURIComponent(str)); }

/* ══════════════════════════════════════════════════
   DÉCLENCHEMENT ALERTE
══════════════════════════════════════════════════ */
function triggerAlert(level) {
  pendingLevel = level;
  const cfg = CONFIRM[level];
  document.getElementById('confirm-title').textContent = cfg.title;
  document.getElementById('confirm-desc').textContent  = cfg.desc;
  const btn = document.getElementById('confirm-action-btn');
  btn.textContent      = cfg.label;
  btn.style.background = cfg.bg;
  document.getElementById('confirm-modal').style.display = 'flex';
}

function confirmAlert() {
  closeConfirmModalDirect();
  const body = {
    lat:   TOULOUSE[0] + (Math.random() - 0.5) * 0.012,
    lon:   TOULOUSE[1] + (Math.random() - 0.5) * 0.016,
    level: pendingLevel,
    description: 'Alerte envoyée depuis SafeWay.',
    lieu: 'Ma position actuelle'
  };
  fetch('/api/alerts', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify(body)
  })
  .then(r => r.json())
  .then(alert => {
    allAlerts.push(alert);
    const m = addMarkerToMap(alert);
    map.panTo([alert.lat, alert.lon], { animate:true, duration:0.7 });
    // Flash du marqueur
    setTimeout(() => m.setStyle({ weight:5, fillOpacity:1 }), 250);
    setTimeout(() => m.setStyle({ weight:2.5, fillOpacity:0.9 }), 650);
    updateCounter();
    showToast(TOAST_MSG[pendingLevel]);
    if (document.getElementById('screen-alertes').classList.contains('active')) applyFilter(currentFilter);
    pendingLevel = null;
  })
  .catch(() => showToast('❌ Erreur lors de l\'envoi'));
}

/* ══════════════════════════════════════════════════
   MODALE DÉTAIL
══════════════════════════════════════════════════ */
function openAlertModal(alert) {
  if (typeof alert === 'string') alert = JSON.parse(alert);
  const style = BADGE_STYLE[alert.level] || BADGE_STYLE.inquietude;
  const badge = document.getElementById('modal-badge');
  badge.textContent      = LABELS[alert.level];
  badge.style.background = style.bg;
  badge.style.color      = style.color;
  document.getElementById('modal-lieu').textContent  = alert.lieu;
  document.getElementById('modal-heure').textContent = `⏱ ${alert.heure}`;
  document.getElementById('modal-desc').textContent  = alert.description;
  document.getElementById('alert-modal').style.display = 'flex';
}
function closeAlertModal(e)      { if (e.target===e.currentTarget) closeAlertModalDirect(); }
function closeAlertModalDirect() { document.getElementById('alert-modal').style.display = 'none'; }

/* ══════════════════════════════════════════════════
   MODALE CONFIRMATION
══════════════════════════════════════════════════ */
function closeConfirmModal(e)      { if (e.target===e.currentTarget) closeConfirmModalDirect(); }
function closeConfirmModalDirect() { document.getElementById('confirm-modal').style.display = 'none'; pendingLevel = null; }

/* ══════════════════════════════════════════════════
   TOAST
══════════════════════════════════════════════════ */
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.style.display = 'block';
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.style.display = 'none'; }, 3800);
}

/* ══════════════════════════════════════════════════
   SPLASH SCREEN
══════════════════════════════════════════════════ */
function enterApp() {
  const splash = document.getElementById('splash');
  splash.classList.add('exit');
  // Supprime le splash du DOM après la transition CSS (600ms)
  setTimeout(() => splash.remove(), 650);
}

/* ══════════════════════════════════════════════════
   INIT
══════════════════════════════════════════════════ */
window.addEventListener('DOMContentLoaded', () => {
  restoreDarkMode();
  initMap();
});
